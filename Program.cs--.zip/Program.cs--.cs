﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {

        public static void Main(string[] args)
        {
            IPIT14.Generator kodgenerator = new IPIT14.Generator();
            string code = kodgenerator.NewCombination(4, false);


            string gissning;
            int totalguess = 6;
            int counter = 0;
            bool win = false;

            Console.WriteLine("Welcome to Mastermind");
            Console.WriteLine("You have six guesses:");
            while (counter < totalguess && !win)
            {
                Console.Write("Guess: ");
                gissning = Console.ReadLine();

                if (gissning == code)
                {
                    Console.WriteLine("OMG!!YOU WON");
                    Console.ReadKey();
                    win = true;
                }
                gissning = kollaInnehåll(gissning);
                int indexFörGissning = 0;
                while (indexFörGissning < 4)
                {
                    bool test = true;
                    if (gissning[indexFörGissning] == code[indexFörGissning])
                    {
                        Console.Write('X');
                        test = false;
                    }
                    while (test)
                    {
                        Contains(gissning, code, indexFörGissning);
                        test = false;
                    }
                    indexFörGissning = indexFörGissning + 1;
                }

                counter++;
                int guessleft = totalguess - counter;
                Console.WriteLine("\nWrong kombination, you have " + guessleft + " guesses left!");

                if (counter == 6)
                {
                    Console.WriteLine("Buuuu!! You lose!");
                    Console.Write("The code was " + code);
                    Console.ReadLine();
                }


            }


        }
        public static string kollaInnehåll(string a)
        {

            string text = a.Substring(0) + "    ";
            return text;

        }
        public static void Contains(string gissning, string code, int index)
        {
            int index2 = 0;
            while (index2 < 4)
            {
                if (gissning[index] == code[index2])
                {
                    Console.Write("O");
                }
                index2++;
            }
            index++;


        }
    }
}
